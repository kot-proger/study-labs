﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mandelbrot_fractal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void Draw()
        {
            Bitmap bmp = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            for (int x = 0; x < pictureBox1.Width; x++)
            {
                for (int y = 0; y < pictureBox1.Height; y++)
                {
                    double a = (double)(x + (pictureBox1.Width / 2)) / (double)(pictureBox1.Width / 4);
                    double b = (double)(y + (pictureBox1.Height / 2)) / (double)(pictureBox1.Height / 4);

                    Complex c = new Complex(a, b);
                    Complex z = new Complex(0, 0);

                    int iter = 0;
                    do
                    {
                        iter++;
                        z.Sqr();
                        z.Add(c);
                        if (z.Magn() > 2.0d)
                        {
                            break;
                        }
                    } while (iter < 100);

                    bmp.SetPixel(x, y, iter < 100 ? Color.FromArgb(iter, iter, iter) : Color.FromArgb(255, 255, 255));
                    //bmp.SetPixel(x, y, iter < 100 ? Color.FromArgb(iter % 2 * 128, iter % 4 * 55, iter % 2 * 77) : Color.FromArgb(iter, iter, iter));
                    //bmp.SetPixel(x, y, Color.FromArgb((byte)(iter * 2.55), (byte)(iter * 2.55), (byte)(iter * 2.55)));
                }
                //pictureBox1.Image = bmp;
            }

            pictureBox1.Image = bmp;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Draw();
        }
    }
}
